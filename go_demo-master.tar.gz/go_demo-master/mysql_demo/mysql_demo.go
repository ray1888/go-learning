package main

import (
	"fmt"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
	"log"
)

type Student struct {
	gorm.Model
	Name   string `sql:"name"`
	Age    int    `sql:"age"`
	School string `sql:"school"`
}

func main() {

	// 为了处理time.Time，需要包括parseTime=True作为参数
	db, err := gorm.Open("mysql", "root:ssss@tcp(0.0.0.0:3306)/test?charset=utf8&parseTime=True")
	if err != nil {
		log.Println("failed to connect database", err)
		return
	}
	defer db.Close()

	// Migrate the schema
	db.AutoMigrate(&Student{})

	// Create
	//fmt.Println(db.Create(&Student{Name: "张三", Age: 15, School: "广州一中"}).Error)
	//fmt.Println(db.Create(&Student{Name: "李四", Age: 14, School: "广州实验中学"}).Error)
	//fmt.Println(db.Create(&Student{Name: "王五", Age: 16, School: "广州七中"}).Error)

	// Read
	var s Student
	db.First(&s, "age = ?", "15") // find product with code l1212

	fmt.Println(s)

	// Update - update product's price to 20
	fmt.Println(db.Model(&s).Where("name = ?", "张三").Update("age", 20).Error)

	// Delete - delete product
	//db.Delete(&s)
}
