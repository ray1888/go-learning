package main

import "sync"

/*
 *这里实现了一个共享的map, 内置的map类型是部分goroutine安全的
 *
*/


var TailInstance Instance

// 任务ID作为Key
type Instance struct {
	m sync.Map
}

// 是否有任务处于运行中
func (i *Instance) Thas(key string) (string,bool) {
	var session string
	value, ok := i.m.Load(key)
	if value == nil{
		return session,ok
	}
	return value.(string),ok
}

func (i *Instance) Tall() []string {
	var sessions []string
	i.m.Range(func(k, v interface{}) bool {

		sessions= append(sessions,v.(string))
		return true
	})
	return sessions
}

func (i *Instance) Tadd(key string,session string) {
	i.m.Store(key, session)
}

func (i *Instance) Tdone(key string) {
	i.m.Delete(key)
}