package main

import (
	"fmt"
	"runtime"
)

func Count(ch chan int) {
	ch <- 1
	fmt.Println("Counting")
}

func main() {
	//显式指定编译器将goroutine调度到多个CPU上运行
	fmt.Println(runtime.NumCPU())
	runtime.GOMAXPROCS(2)
	//实现有缓冲的chanel
	chs := make([] chan int, 10)

	for i:=0; i<10; i++ {
		chs[i] = make(chan int)
		go Count(chs[i])
	}

	for _, ch := range(chs) {
		<-ch
	}
}