# grpc-java-demo



# 编译


进入项目目录命令行执行：

`mvn clean package`


# 运行

```
启动服务端
java -jar target/grpc-java-demo-1.0-SNAPSHOT-jar-with-dependencies.jar server


启动客户端
java -jar target/grpc-java-demo-1.0-SNAPSHOT-jar-with-dependencies.jar client

```


# proto生成java代码

修改代码 `src/main/proto` 中的helloworld.proto.example 为helloworld.proto

执行 `mvn clean install` 会在target目录下面生成grpc java代码


# 在IDE中运行server和client代码

将grpc ptoto生成代码目录添加到工程代码中， 可以使用link方式


# 其它配置

修改pom.xml 配置中的 `<directory>${project.basedir}/../helloworld/</directory>` 
目录为proto生成的java目录

注：

需要生成gRPC 通讯部分代码 `GreeterGrpc.java`

需要通过插件： protoc-gen-grpc-java插件生成

> 参考： http://blog.csdn.net/freewebsys/article/details/58584294 

也可以用步骤 《4、ptoto生成java代码》，来操作生成java代码， 然后配置`<directory>` 为生成之后的目录即可
