package io.grpc.examples.helloworld;

import java.io.IOException;
import java.util.Arrays;



public class CommandApp {

    public static void main(String[] args) throws IOException, InterruptedException {

        if(args.length > 0) {
            System.out.println(Arrays.toString(args));
            String cmd = args[0].toLowerCase();
            
            //启动服务端
            if("server".equals(cmd)) {
                
                final HelloWorldServer server = new HelloWorldServer();
                server.start();
                server.blockUntilShutdown();
            }
            //启动客户端
            if ("client".equals(cmd)) {
                
                int port = 50051;
                if(args.length>1) {
                    port = Integer.parseInt(args[1]);
                }
                
                HelloWorldClient client = new HelloWorldClient("localhost", port);
                try {
                 /* Access a service running on the local machine on port 50051 */
                 String user = "worldssssssssssssss";
                 if (args.length > 0) {
                   user = args[0]; /* Use the arg as the name to greet if provided */
                 }
                 client.greet(user);

               } finally {
                 client.shutdown();
               }
               System.out.println("#############finish##############");
                
            }
        }

    }

}
