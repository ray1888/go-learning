# go_demo

## 概述

该示例共提供了：

* 3种数据库连接：`mysql`、`redis`、`mongo`
* 2种接口调用形式：`http`、`grpc`
* goroutine的常见使用方法

注：

* demo中的文件都可以单独执行，数据库连接都可以连接到直播这边的测试环境，可以直接连。
* grpc由于目前没有项目在用，所以demo中只是跑通了官方demo

### go环境配置

* go install

    网上很多教程，可参考官网[https://golang.org/doc/install](https://golang.org/doc/install)

* IDE

    推荐[goland](https://www.jetbrains.com/go/) 或[IDEA + Golang插件 ](https://www.jetbrains.com/idea/) 
    
* 包管理

    目前使用官方工具[dep](https://github.com/golang/dep)

* 语法学习

    推荐看[教程](https://github.com/astaxie/build-web-application-with-golang)

### mysql

* orm使用的是：[http://jinzhu.me/gorm/](http://jinzhu.me/gorm/)

    安装方法：`go get -u github.com/jinzhu/gorm`

* mysql驱动使用的是：[https://github.com/go-sql-driver/mysql](https://github.com/go-sql-driver/mysql)

    安装方法：`go get -u github.com/go-sql-driver/mysql`

### redis

* redis驱动使用的是：[https://godoc.org/gopkg.in/redis.v5](https://godoc.org/gopkg.in/redis.v5)

    安装方法：`go get -u gopkg.in/redis.v5`

### mongo

* mongo驱动使用的是：[https://godoc.org/gopkg.in/mgo.v2](https://godoc.org/gopkg.in/mgo.v2)

    安装方法：`go get -u gopkg.in/mgo.v2`

### http

* `server`: 一个完整的server项目，实现了优雅关闭，模块路由，超时报警等
* `client`: 这个是我们自己封装的标准库，用于访问系统间的内部接口，对于常见的`get/post`方法进行了封装，提供了超时机制、可以设置格式化的header。

### grpc

* 使用的是：[https://github.com/grpc/grpc-go](https://github.com/grpc/grpc-go)

    安装方法：

    * 安装protobuf

        go get -u github.com/golang/protobuf/{proto,protoc-gen-go}

    * 安装grpc

        go get -u google.golang.org/grpc

    * 生成go代码

        protoc --go_out=plugins=grpc:. *.proto
        
        
        
### 翻墙方法
Golang很多地方需要翻墙, 特别是安装第三方依赖库时,推荐如下方法
* VPN全局翻墙
* Shadowsocks

#### Shadowsocks 终端翻墙方法

终端中执行以下命令, 假设代理端口为1235
```
export https_proxy="http://127.0.0.1:1235" 
export http_proxy="http://127.0.0.1:1235"
git config --global http.https://github.com.proxy http://127.0.0.1:1235
```
#### 服务器翻墙方法

* ssh上传,服务器翻墙比较麻烦,一般我们的做法是本地电脑下载好, 直接把文件通过ssh上传到服务器对应的目录即可. 使用Docker后,只需要配置好一次镜像,以后无需要再配置
* 直接把构建机地区购买成香港美国等地区的即可, 只需要构建机翻墙,其他机器直接拉二进制文件


#### 常见库

```
https://github.com/bitly/go-simplejson 处理Json

https://github.com/avelino/awesome-go

https://github.com/xiao-zhibo/work  利用Redis做定时任务,直播这边使用很广

https://github.com/go-kit/kit Golang微服务相关

https://github.com/patrickmn/go-cache Golang 内存缓存, 内存缓存速度优于Redis, 有时可以考虑内存缓存

https://github.com/denverdino/aliyungo  阿里云相关Golang工程

https://github.com/tealeg/xlsx xlsx文件处理工程

https://github.com/golang/freetype Golang绘图相关, 绘制图片需要使用这个

https://github.com/mitchellh/mapstructure


```







