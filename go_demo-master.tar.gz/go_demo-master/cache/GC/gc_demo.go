package main

import (
	"time"
	"sync"

)


// LRUCacher implments cache object facilities
type LRUCacher struct {
	mutex          sync.Mutex
	MaxElementSize int
	Expired        time.Duration
	GcInterval     time.Duration
}

// RunGC run once every m.GcInterval
func (m *LRUCacher) RunGC() {
	time.AfterFunc(m.GcInterval, func() {
		m.RunGC()
		m.GC()
	})
}

// GC check ids lit and sql list to remove all element expired
func (m *LRUCacher) GC() {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	//do something
}