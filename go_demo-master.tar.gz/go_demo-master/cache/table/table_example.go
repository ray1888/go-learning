package table

import (
	"gitlab.gz.cvte.cn/go_demo/go_demo/cache/cache"
	"fmt"
	"reflect"
)


type User struct {
	Name string `cacheIndex:"Name" cacheType:"redis"`
	Content string
	Id   int64
}

func init()  {
	cache.Orm.CreateTables(&User{})
	ReloadAll()
}

func ReloadAll() {
	cache.DeleteByTableName(reflect.TypeOf(User{}).Name())
	everyone := make([]User, 0)
	cache.Orm.Find(&everyone)
	fmt.Println(everyone)
	for _,v:= range everyone {
		cache.ReloadBaseElment(v)
	}
}
