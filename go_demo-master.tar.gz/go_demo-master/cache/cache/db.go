package cache

import (
	"os"
	"github.com/go-xorm/xorm"
	"fmt"
	_ "github.com/mattn/go-sqlite3"
)

var Orm *xorm.Engine
func init()  {
	f := "test.db"
	os.Remove(f)
	var err error
	Orm, err = xorm.NewEngine("sqlite3", f)
	if err != nil {
		fmt.Println(err)
		return
	}


}





