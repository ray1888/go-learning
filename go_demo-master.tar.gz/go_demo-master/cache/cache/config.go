package cache

import "time"

const SaveInterval = time.Second *10