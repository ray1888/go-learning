package cache

import (
	"sync"
)

type InstanceFather interface {
	Thas(key string) (interface{},bool)
	Tall() []interface{}
	Tadd(key string,value interface{})
	Tdone(key string)
	RunGC()
	GC()
	StopGC()
}


var instanceMap  sync.Map


func DeleteByTableName (tableName string)  {
	instance, exsit :=instanceMap.Load(tableName)
	if !exsit {
		return
	}
	instance.(InstanceFather).StopGC()
	instanceMap.Delete(tableName)
}



func GetInstanceByName(tpy,name string) InstanceFather {
	switch tpy {
	case "memory":
		instance, exsit :=instanceMap.Load(name)

		if exsit {
			return instance.(*MInstance)
		}else {
			newInstance:= new(MInstance)
			instanceMap.Store(name,newInstance)

			newInstance.RunGC()
			return newInstance
		}
	case "redis":
		instance, exsit :=instanceMap.Load(name)

		if exsit {
			return instance.(*RedisInstance)
		}else {
			newInstance:= new(RedisInstance)
			newInstance.tableName = name
			instanceMap.Store(name,newInstance)

			newInstance.RunGC()
			return newInstance
		}


	}

	return new(MInstance)
}

