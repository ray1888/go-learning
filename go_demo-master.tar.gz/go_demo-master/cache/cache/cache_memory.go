package cache

import (
	"sync"
	"time"
	"fmt"
)

type MInstance struct {
	m sync.Map
	stopStag bool
}


func (i *MInstance) Thas(key string) (interface{},bool) {
	return i.m.Load(key)
}

func (i *MInstance) Tall() []interface{} {
	var values []interface{}
	i.m.Range(func(k, v interface{}) bool {
		values= append(values,v)
		return true
	})
	return values
}

func (i *MInstance) Tadd(key string,value interface{}) {
	i.m.Store(key, value)
}

func (i *MInstance) Tdone(key string) {
	i.m.Delete(key)
}

func (i *MInstance)StopGC() {
	i.stopStag = true
}
func (i *MInstance) RunGC() {
	if !i.stopStag {
		time.AfterFunc(SaveInterval, func() {
			i.RunGC()
			i.GC()
		})
	}

}

func (i *MInstance) GC() {
	i.m.Range(func(k, v interface{}) bool {
		m := v.(*BaseElement)
		if m.WaitDelete {
			//从数据库删除元素
			m.Delete()
			m.WaitDelete = false
		}
		if m.WaitSaved {
			//向数据库存储元素
			m.Insert()

		}
		if m.WaitUpdate {
			//从数据库更新元素
			fmt.Println(m)
			m.Update()
			m.WaitUpdate = false
		}
		return true
	})
}


