package cache


import (
	"time"
	"fmt"
	"gopkg.in/redis.v5"
	"log"
	"sync"
)

type RedisInstance struct {
	tableName string
	groupName string  //预留参数
	stopStag bool
}
var (
	redisConn *redis.Client
	syncOnce  sync.Once

	host  string = "localhost:6379"
	pswd  string = ""
	dbNum int    = 10
)

const (
	DEFAULT_EXPIRATION = 60

	LOGFMT_ERROR                  = "error: %v \n"
	LOGFMT_REDIS_DEL_OK           = "redis del ok, key: %v \n"
	LOGFMT_REDIS_DEL_ERROR        = "redis del error, key: %v  error: %s \n"
	LOGFMT_REDIS_SET_EXPIRE_ERROR = "redis set expire error, key: %s  error: %s \n"
)

func GetClient() *redis.Client {
	syncOnce.Do(
		func() {
			redisConn = redis.NewClient(&redis.Options{
				Addr:     host,
				Password: pswd,
				DB:       dbNum,
			})
			log.Printf("INFO(%s): Connect to redis status.", redisConn.Ping().String())
		},
	)
	return redisConn
}

func (i *BaseElement)getRedisValue(key string) error {
	return GetClient().Get(key).Scan(i)
}



func setRedisValue(key string, value interface{}, expiration int) error {
	return GetClient().Set(key, value, time.Second*time.Duration(expiration)).Err()
}

func delRedisValue(keys ...string) error {
	return GetClient().Del(keys...).Err()
}


func (i *RedisInstance) Thas(key string) (interface{},bool) {
	newEle:= new(BaseElement)
	err:=newEle.getRedisValue(i.tableName+"_"+key)
	if err!=nil {
		return nil,false
	}
	return newEle,true
}

func (i *RedisInstance) Tall() []interface{} {
	var values []interface{}
	GetClient().Keys(i.tableName+"*").ScanSlice(values)
	return values
}

func (i *RedisInstance) Tadd(key string,value interface{}) {

	err:=setRedisValue(i.tableName+"_"+key,value,0)
	fmt.Println(err)
}

func (i *RedisInstance) Tdone(key string) {
	delRedisValue(i.tableName+"_"+key)
}

func (i *RedisInstance)StopGC() {
	i.stopStag = true
}
func (i *RedisInstance) RunGC() {
	if !i.stopStag {
		time.AfterFunc(SaveInterval, func() {
			i.RunGC()
			i.GC()
		})
	}

}

func (i *RedisInstance) GC() {
	for _,v:=range i.Tall(){
		m := v.(*BaseElement)
		if m.WaitDelete {
			//从数据库删除元素
			m.Delete()
			m.WaitDelete = false
		}
		if m.WaitSaved {
			//向数据库存储元素
			m.Insert()

		}
		if m.WaitUpdate {
			//从数据库更新元素
			fmt.Println(m)
			m.Update()
			m.WaitUpdate = false
		}
	}
}

