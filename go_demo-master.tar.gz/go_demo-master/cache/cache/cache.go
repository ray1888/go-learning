package cache

import (
	"time"
	"sync"
	"reflect"
	"errors"
	"github.com/sirupsen/logrus"
	"fmt"
)

type BaseElement struct {
	WaitDelete bool
	WaitSaved bool
	WaitUpdate bool
	mutex   sync.Mutex
	SearchKey  string
	SearchValue string
	//TableName string
	TableInstance InstanceFather
	//Data  map[string]interface{}
	Sure interface{}
}

//缓存操作方法
type CacheMethod interface {
	cacheFind() error
	cacheNew()  *BaseElement
	cacheUpdate()  (bool,error)
	cacheDelete()
}

//数据库操作方法
type OrmMethod interface {
	Update()
	Insert()
	Delete()
}

func NewBaseElment(bean interface{}) *BaseElement {

	if err:=judgeNoPtr(bean);err!=nil {
		return nil
	}

	newBaseElement := new(BaseElement)
	rbean :=rValue(bean)
	newBaseElement.TableInstance = GetInstanceByName(rbean.Type().Field(0).Tag.Get("cacheType"),rbean.Type().Name())
	newBaseElement.SearchKey =  rbean.Type().Field(0).Tag.Get("cacheIndex")
	newBaseElement.Sure = bean
	newBaseElement.WaitSaved = true

	return newBaseElement.cacheNew()
}

func ReloadBaseElment(bean interface{}){
	if err:=judgeNoPtr(bean);err!=nil {
		return
	}
	newBaseElement := new(BaseElement)
	rbean :=rValue(bean)
	newBaseElement.TableInstance = GetInstanceByName(rbean.Type().Field(0).Tag.Get("cacheType"),rbean.Type().Name())
	newBaseElement.SearchKey =  rbean.Type().Field(0).Tag.Get("cacheIndex")
	newBaseElement.Sure = bean
	newBaseElement.cacheNew()
}

func rValue(bean interface{}) reflect.Value {
	return reflect.Indirect(reflect.ValueOf(bean))
}

func judgeBean(bean interface{})  error{
	beanValue := reflect.ValueOf(bean)
	if beanValue.Kind() != reflect.Ptr {
		return errors.New("needs a pointer to a value")
	} else if beanValue.Elem().Kind() == reflect.Ptr {
		return errors.New("a pointer to a pointer is not allowed")
	}
	return nil
}

func judgeNoPtr(bean interface{})  error{
	beanValue := reflect.ValueOf(bean)
	if beanValue.Kind() == reflect.Ptr {
		return errors.New("can't set  a pointer to a value")
	}
	return nil
}

func CacheFindByKey(bean interface{}) error {
	//对参数进行指针判断
	if err:=judgeBean(bean);err!=nil {
		return err
	}
	newBaseElement := new(BaseElement)
	rbean :=rValue(bean)
	newBaseElement.TableInstance = GetInstanceByName(rbean.Type().Field(0).Tag.Get("cacheType"),rbean.Type().Name())
	newBaseElement.SearchValue =  rbean.Field(0).String()
	newBaseElement.SearchKey =  rbean.Type().Field(0).Tag.Get("cacheIndex")
	newBaseElement.Sure = bean
	if err :=newBaseElement.cacheFind();err!=nil {
		return err
	}
	reflect.ValueOf(bean).Elem().Set(rValue(newBaseElement.Sure))
	return nil
}

func CacheDeleteBykey(bean interface{}) (bool,error) {
	//对参数进行指针判断
	if err:=judgeBean(bean);err!=nil {
		return false,err
	}
	newBaseElement := new(BaseElement)
	rbean :=rValue(bean)
	newBaseElement.TableInstance = GetInstanceByName(rbean.Type().Field(0).Tag.Get("cacheType"),rbean.Type().Name())
	newBaseElement.SearchValue =  rbean.Field(0).String()
	newBaseElement.cacheDelete()
	return true,nil
}

func CacheUpdateBykey(bean interface{}) (bool,error)  {
	if err:=judgeNoPtr(bean);err!=nil {
		return false,err
	}
	newBaseElement := new(BaseElement)
	rbean :=rValue(bean)
	newBaseElement.TableInstance = GetInstanceByName(rbean.Type().Field(0).Tag.Get("cacheType"),rbean.Type().Name())
	newBaseElement.SearchValue =  rbean.Field(0).String()
	newBaseElement.Sure = bean

	return newBaseElement.cacheUpdate()
}

func (m *BaseElement) cacheFind() error{
	//查询先判断WaitSaved，存储后再返回
	data,exist := m.TableInstance.Thas(m.SearchValue)

	if !exist {
		//v1.0 找不到从数据库找，并写入内存
		//if err:=m.Select();err!=nil {
		//	return err
		//}
		//m.cacheNew()
		//return nil

		//v2.0 数据在一开始就全部load 进内存了
		return errors.New("can't find element")

	}
	sm  := data.(*BaseElement)
	sm.mutex.Lock()
	defer sm.mutex.Unlock()
	if sm.WaitSaved {
		//向数据库存储元素
		sm.Insert()
	}

	m.Sure = sm.Sure
	return nil
}

func (m *BaseElement) cacheNew()  *BaseElement{
	m.SearchValue = reflect.ValueOf(m.Sure).Field(0).String()
	_,exist := m.TableInstance.Thas(m.SearchValue)
	if exist {
		return nil
	}
	//TODO map是线程部分安全，这里需要进行测试
	m.TableInstance.Tadd(m.SearchValue,m)
	return m

}
func (m *BaseElement) cacheUpdate()  (bool,error){
	data,exist := m.TableInstance.Thas(m.SearchValue)
	if !exist {
		return false,errors.New("can't find element")
	}
	old := data.(*BaseElement)
	old.mutex.Lock()
	defer old.mutex.Unlock()
	old.WaitUpdate = true
	//交换Data数据
	old.Sure = m.Sure
	return true,nil

}

func (m *BaseElement) cacheDelete()  {
	data,exist := m.TableInstance.Thas(m.SearchValue)
	if !exist {
		return
	}
	old := data.(*BaseElement)
	old.mutex.Lock()
	defer old.mutex.Unlock()
	old.TableInstance.Tdone(old.SearchValue)
	time.AfterFunc(time.Duration(SaveInterval), func() {
		old.Delete()
	})


}

func (m *BaseElement) Select() error {
	logrus.Info("select",m.Sure)
	exist,err:=Orm.Where(fmt.Sprintf("%s=?",m.SearchKey),m.SearchValue).Get(m.Sure)

	if err!=nil {
		return err
	}
	if !exist{
		return errors.New("can't find element")
	}
	return nil
}

func (m *BaseElement) Insert() {
	logrus.Debug("insert",m.Sure)
	_,err:=Orm.Insert(m.Sure)
	if err!=nil {
		logrus.Error(err)
		return
	}
	m.WaitSaved = false
}

func (m *BaseElement) Delete() {
	logrus.Info("delete")
	_,err:=Orm.Delete(m.Sure)
	if err!=nil {
		logrus.Error(err)
		return
	}
	m.WaitDelete = false
}



func (m *BaseElement) Update() {
	logrus.Debug("update")
	_,err:=Orm.Where(fmt.Sprintf("%s=?",m.SearchKey),m.SearchValue).Update(m.Sure)
	if err!=nil {
		logrus.Error(err)
		return
	}
	m.WaitUpdate = false
}