package main


import (
	"gitlab.gz.cvte.cn/go_demo/go_demo/cache/cache"
	"fmt"
	"gitlab.gz.cvte.cn/go_demo/go_demo/cache/table"
	"time"
	"strconv"
)

func main()  {


	//新增和更新不传指针，查询和删除传指针

		//新增
		go func() {
			for i:=0;i<10;i++ {
				cache.NewBaseElment(table.User{Name: "测试一下" + strconv.Itoa(i), Content: `img_data =`})
		}
		}()
	search := new(table.User)
	search.Name = "测试一下0"
	err:=cache.CacheFindByKey(search)
	fmt.Println(err)


	//更新
	//go func() {
	//	for i:=0;i<10;i++ {
	//		cache.CacheUpdateBykey(table.User{Name: "测试一下0", Content: "dddd" + strconv.Itoa(i)})
	//		//fmt.Println(err)
	//	}
	//}()





		search2 := new(table.User)
		search2.Name = "测试一下0"
		cache.CacheFindByKey(search2)
		fmt.Println(search2)

		//删除
		//cache.CacheDeleteBykey(search2)

	cache.CacheFindByKey(search2)
	fmt.Println(search2)
	time.Sleep(time.Second*10)
	cache.DeleteByTableName("User")
	time.Sleep(time.Second*10)

}
