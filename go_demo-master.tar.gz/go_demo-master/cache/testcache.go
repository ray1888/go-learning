package main

import (
	"gitlab.gz.cvte.cn/go_demo/go_demo/cache/cache"
	"fmt"
	"reflect"
)

func main()  {
	var ins  cache.InstanceFather

	ins = cache.GetInstanceByName("memory","test")

	fmt.Println(reflect.TypeOf(ins))
}
