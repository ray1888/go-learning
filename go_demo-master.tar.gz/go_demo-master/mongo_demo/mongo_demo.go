package main

import (
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"log"
	"sync"
)

func main() {
	Connect()
	defer CloseSession()

	var (
		name = "zhangsan"
		//age      = 18
		//itemList = []string{
		//	"phone", "computer", "car", "house", "girlfriend",
		//}
	)

	session := CopySession()
	defer session.Close()

	//err := mongoInsert(session, name, age, itemList)
	//log.Println("mongoInsert error:", err)

	//err := mongoDelete(name)
	//log.Println("mongoDelete error:", err)

	//err := mongoUpdate(session, name, 20)
	//log.Println("mongoUpdate error:", err)

	err := mongoFind(session, name)
	log.Println("mongoUpdate error:", err)

}

// =============================== connection ========================
var (
	globalSession *mgo.Session
	sessionOnce   sync.Once

	mongoUri string = "mongodb://root:............"
	dbName   string = "test"
)

// Connect - Connect to mongo db
func Connect() {
	sessionOnce.Do(func() {
		var err error
		log.Printf("INFO(%s): Echo mongo conn uri.", mongoUri)
		globalSession, err = mgo.Dial(mongoUri)
		if err != nil {
			log.Printf("FETAL(%s): Mongo connect error!", err.Error())
			// todo: 邮件报警
			return
		} else {
			log.Println("SUCCESS(nil): Mongo connect success!")
		}
		// SetMode changes the consistency mode for the session.
		globalSession.SetMode(mgo.Monotonic, true)
	})
}

// 注意这个函数只关闭全局的Session,不是复制的Session
func CloseSession() {
	globalSession.Close()
}

// 每次需要使用数据库时, 调用这个函数, 这个函数复制了一个连接的信息,并且在并发需要的时候会创建新的连接
//  一定要在复制出来的对象中调用defer session.Close()  否则连接被泄露了
func CopySession() *mgo.Session {
	return globalSession.Copy()
}

func CopyStrongSession() *mgo.Session {
	s := globalSession.Copy()
	s.SetMode(mgo.Strong, false)
	return s
}

// ==================== base funcs =====================================

type dataStruct struct {
	Name     string   `bson:"name"`
	Age      int      `bson:"age"`
	ItemList []string `bson:"item_list"`
}

// insert
func mongoInsert(session *mgo.Session, name string, age int, itemList []string) error {
	data := dataStruct{
		Name:     name,
		Age:      age,
		ItemList: itemList,
	}

	conn := session.DB(dbName).C("test")
	err := conn.Insert(data)
	return err
}

// delete
func mongoDelete(session *mgo.Session, name string) error {

	conn := session.DB(dbName).C("test")

	selector := bson.M{
		"name": name,
	}
	return conn.Remove(selector)
}

// update
func mongoUpdate(session *mgo.Session, name string, age int) error {
	conn := session.DB(dbName).C("test")
	selector := bson.M{
		"name": name,
	}
	update := bson.M{
		"$set": bson.M{ // update 操作，这里一定要加上 $set 操作符
			"age": age,
		},
	}
	return conn.Update(selector, update)
}

// find
func mongoFind(session *mgo.Session, name string) error {
	conn := session.DB(dbName).C("test")
	selector := bson.M{
		"name": name,
	}

	var result dataStruct
	err := conn.Find(selector).One(&result)
	if err == nil {
		log.Printf("find result: %+v\n", result)
	}
	return err
}
