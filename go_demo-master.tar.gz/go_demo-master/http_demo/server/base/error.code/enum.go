package ec

// 模块接口基础错误码
const (
	InitCode      int = 40000
	ErrorInitCode int = iota * InitCode
	ErrorSysCode
	ErrorLiveRoomCode
	ErrorImageCode
	ErrorStorageCode
)

// 基础接口错误码
var (
	Success                = ErrorCode{Err: 0, Msg: "success"}
	InvalidArgument        = ErrorCode{Err: 1, Msg: "invalid argument"}
	LackOfArguments        = ErrorCode{Err: 2, Msg: "lack of arguments"}
	ResourceUnavailable    = ErrorCode{Err: 3, Msg: "resource unavailable"}
	WrongMimetypeJSON      = ErrorCode{Err: 4, Msg: "expect application/json"}
	Retry                  = ErrorCode{Err: 5, Msg: "please try again"}
	TemporarilyUnavailable = ErrorCode{Err: 6, Msg: "temporarily unavailable"}
	Unknown                = ErrorCode{Err: 7, Msg: "unknown error"}
	Fail                   = ErrorCode{Err: 8, Msg: "fail"}
	MongodbOp              = ErrorCode{Err: 9, Msg: "mongodb operation error"}
	LiveRoomQuestion       = ErrorCode{Err: 10, Msg: "not found that question"}
)

// 业务级通用错误码
var (
	ErrorInvalidUserToken      = ErrorCode{Err: ErrorInitCode + 1, Msg: "invalid user or token."}
)
