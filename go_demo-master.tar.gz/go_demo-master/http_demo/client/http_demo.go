package main

import (
	"bytes"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

// ============================= 自己包装的请求函数 =============================== begin

var DefaultClient = &http.Client{
	Timeout: time.Second * 10,
}

type ResponseError struct {
	Status int    `json:"status,_"`
	Err    int    `json:"err,omitempty"`
	Msg    string `json:"msg,omitempty"`
}

func (e ResponseError) Error() string {
	data, _ := json.Marshal(e)
	return string(data)
}

func (x *XClient) HeaderSignature(header *http.Header) *http.Header {
	if header == nil {
		header = &http.Header{ContentType: {FormContentType}}
	}
	if x.AppKey != "" {
		if x.KeyType == KEY_TYPE_1 {
			nonce := strconv.Itoa(rand.Int())
			nowtime := strconv.FormatInt(time.Now().Unix(), 10)
			t := sha1.New()
			io.WriteString(t, x.AppSecret+nonce+nowtime)
			sign := fmt.Sprintf("%x", t.Sum(nil))
			header.Add("appId", x.AppKey)
			header.Add("rand", nonce)
			header.Add("time", nowtime)
			header.Add("sign", sign)
		} else if x.KeyType == KEY_TYPE_2 {
			header.Set("Authorization", "Basic "+basicAuth(x.AppKey, x.AppSecret))
		}
	}

	return header
}

func durationToMs(d time.Duration) string {
	ms := d / time.Millisecond
	nsec := d % time.Millisecond
	return fmt.Sprintf("%.2fms", float64(ms)+float64(nsec)*1e-6)
}

func basicAuth(username, password string) string {
	auth := username + ":" + password
	return base64.StdEncoding.EncodeToString([]byte(auth))
}

func (x *XClient) request(reqUrl *url.URL, method string, params *url.Values, header *http.Header) (*http.Request, error) {
	var body io.Reader

	if params != nil {
		if method == http.MethodGet {
			reqUrl.RawQuery = params.Encode()
		} else {
			if header == nil {
				body = strings.NewReader(params.Encode())
			} else if header.Get(ContentType) == JsonContentType {
				buf := &bytes.Buffer{}
				err := json.NewEncoder(buf).Encode(params)
				if err != nil {
					return nil, err
				}
				body = buf
			} else {
				body = strings.NewReader(params.Encode())
			}
		}
	}
	//log.Println(reqUrl.String())
	req, err := http.NewRequest(method, reqUrl.String(), body)
	if err != nil {
		log.Println("make request error: ", reqUrl.String(), err)
		return nil, err
	}
	if header != nil {
		req.Header = *header
	}
	return req, nil
}

func (x *XClient) XRequest(apiUrl, method string, params *url.Values, header *http.Header) (*http.Request, error) {
	reqUrl, err := url.Parse(x.Host + apiUrl)
	if err != nil {
		log.Println("error:", err, x.Host, apiUrl)
		return nil, err
	}
	header = x.HeaderSignature(header)
	req, err := x.request(reqUrl, method, params, header)
	if err != nil {
		log.Println("error:", err)
	}
	return req, err
}

func (x *XClient) XRequestJson(apiUrl, method string, body []byte, header *http.Header) (*http.Request, error) {
	reqUrl, err := url.Parse(x.Host + apiUrl)
	if err != nil {
		return nil, err
	}
	header = x.HeaderSignature(header)

	buf := bytes.NewReader(body)
	req, err := http.NewRequest(method, reqUrl.String(), buf)
	if err != nil {
		log.Println("make request error: ", reqUrl.String(), err)
		return nil, err
	}
	req.Header = *header
	return req, err
}

func (x *XClient) Do(req *http.Request, successV interface{}) error {
	if req == nil {
		log.Println("[err]: req is nil !")
		return ResponseError{Err: ERROR_DECODE_DATA, Msg: "[err]: req is nil !"}
	}

	startTime := time.Now()
	resp, err := x.Client.Do(req)

	if err != nil {
		log.Printf("[resp]: %+v\t[err]: %+v\t[url]: %+v\t[time]: %+v\n", resp, err, req.URL.String(), durationToMs(time.Since(startTime)))
		return ResponseError{Err: ERROR_DECODE_DATA, Msg: err.Error()}
	}
	log.Println(req.URL.String(), resp.StatusCode, durationToMs(time.Since(startTime)))

	defer resp.Body.Close()
	var respErr ResponseError
	respErr.Status = resp.StatusCode
	if code := resp.StatusCode; code >= 200 && code <= 299 {
		if successV != nil {
			data, err := ioutil.ReadAll(resp.Body)
			err = json.Unmarshal(data, successV)
			if err != nil {
				respErr.Err = ERROR_DECODE_DATA
				respErr.Msg = err.Error()
				return respErr
			}
		}
		return nil
	} else {
		data, err := ioutil.ReadAll(resp.Body)
		log.Println(string(data))
		err = json.Unmarshal(data, &respErr)
		if err != nil {
			respErr.Err = ERROR_DECODE_DATA
			respErr.Msg = resp.Status
		}
		req.ParseForm()
		log.Println(req.Form, respErr)
	}
	return respErr
}

const (
	ERROR_DECODE_DATA = 8

	KEY_TYPE_1 = 1 // kangaroo, video
	KEY_TYPE_2 = 2 // live, im, gorilla, koala
)

const (
	ContentType     = "Content-Type"
	JsonContentType = "application/json"
	FormContentType = "application/x-www-form-urlencoded"
)

type HttpClient interface {
	Do(req *http.Request) (*http.Response, error)
}

type XClient struct {
	Client    HttpClient
	Host      string
	AppKey    string
	AppSecret string
	KeyType   int // 1: kangaroo, video    2: live,im,gorilla,koala
}

// ============================= 自己包装的请求函数 =============================== end

func main() {
	newClient := XClient{
		Client:    &http.Client{Timeout: time.Second * 5},
		Host:      "",
		AppKey:    "",
		AppSecret: "",
		KeyType:   0,
	}

	// -------------get
	header := http.Header{ContentType: {FormContentType}}
	reqUrl := "http://localhost:8080/api/v1.0/test/testget?name=xiaozhibo"
	req, _ := newClient.XRequest(reqUrl, http.MethodGet, nil, &header)
	result := make(map[string]interface{})
	err := newClient.Do(req, &result)
	fmt.Println(result, err)

	// -------------post
	header = http.Header{ContentType: {FormContentType}}
	reqUrl = "http://localhost:8080/api/v1.0/test/testpost"
	param := url.Values{
		"name": {"xiaozhibo"},
	}
	req, _ = newClient.XRequest(reqUrl, http.MethodPost, &param, &header)
	result = make(map[string]interface{})
	err = newClient.Do(req, &result)
	fmt.Println(result, err)

}
